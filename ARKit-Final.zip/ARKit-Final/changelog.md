# Changelog

- [PR #59 - Routing / Polylines](https://github.com/ProjectDent/ARKit-CoreLocation/pull/159)
    - Adds the ability to take an array of `MKRoute` objects and render it as a route in AR (similar to the demo gif on the README)
    - Updates the demo app to allow you to demonstrate this capability
