//
//  InfoViewController.swift
//  ARKit+CoreLocation
//
//  Created by Karolina Sabonaityte on 4/11/19.
//  Copyright © 2019 Project Dent. All rights reserved.
//

import UIKit

@available(iOS 11.0, *)
class InfoViewController: UIViewController {
    
    @IBOutlet var infoImage: UIImageView!
    var image = UIImage()
    @IBOutlet var infoLabel: UILabel!
    var textt = String()
    @IBOutlet var extraLabel: UILabel!
    var text2 = String()
    var titleText = String()
    @IBOutlet var navigateButton: UIButton!
    @IBAction func navigateTo(_ sender: UIButton) {
    }
    @IBOutlet var navItem: UINavigationItem!
    @IBAction func backButton() {
        self.performSegue(withIdentifier: "unwindToViewController4", sender: self)
    }
    @IBOutlet var titleString: UINavigationItem!
    @IBAction func prepareForUnwind3(segue: UIStoryboardSegue) {
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        extraLabel.layer.masksToBounds = true
        extraLabel.layer.cornerRadius = 5
        self.infoImage.image = self.image
        self.infoLabel.text = self.textt
        self.extraLabel.text = self.text2
        self.navigationItem.title = self.titleText
        self.titleString.title = self.titleText

        // Do any additional setup after loading the view.
    }
    

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "specificDataSegue" {
            let backItem = UIBarButtonItem()
            backItem.title = "Back"
            navigationItem.backBarButtonItem = backItem
            
            let vc = segue.destination as! ARCLSpecificController
            vc.titleText = self.titleText
        }
    }
}
