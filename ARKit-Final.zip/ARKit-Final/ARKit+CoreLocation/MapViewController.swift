//
//  MapViewController.swift
//  ARKit+CoreLocation
//
//  Created by Karolina Sabonaityte on 3/27/19.
//  Copyright © 2019 Project Dent. All rights reserved.
//

import UIKit
import MapKit

class MapViewController: UIViewController, MKMapViewDelegate {

    @IBOutlet var myMap: MKMapView!
    @IBOutlet var titleBar: UINavigationBar!
    
    @IBAction func homeButton() {
        self.performSegue(withIdentifier: "unwindToViewController1", sender: self)
    }
    
    var myTitles = ["The Arch", "Chapel Bell", "Herty Fountain", "Miller Learning Center", "Tate Center", "Sanford Stadium"]
    var latLong = [[33.957547,-83.375286],[33.956620,-83.375395],[33.955703,-83.375511],[33.951700,-83.376100],[33.950500,-83.375000],[33.949800,-83.373366]]
    var myLatitude = 33.953345
    var myLongitude = -83.374444
    
    override func viewDidLoad() {
        
        titleBar.topItem?.title = "Points of Interest"
        
        super.viewDidLoad()
        
        let initialLocation = CLLocation(latitude: myLatitude, longitude: myLongitude)
        let regionRadius: CLLocationDistance = 800
        func centerMapOnLocation(location: CLLocation){
            let coordinateRegion = MKCoordinateRegion(center: location.coordinate, latitudinalMeters: regionRadius, longitudinalMeters: regionRadius)
            myMap.setRegion(coordinateRegion, animated: true)
            myMap.mapType = MKMapType.standard
        }
        centerMapOnLocation(location: initialLocation)
        let howMany = latLong.count
        var latLongCounter = 0
        while (latLongCounter < howMany) {
            let pinLatitude = latLong[latLongCounter][0]
            let pinLongitude = latLong[latLongCounter][1]
            var pinCoordinates: CLLocationCoordinate2D = CLLocationCoordinate2D()
            pinCoordinates.latitude = CDouble(pinLatitude)
            pinCoordinates.longitude = CDouble(pinLongitude)
            let pin: MKPointAnnotation = MKPointAnnotation()
            pin.coordinate = pinCoordinates
            self.myMap.addAnnotation(pin)
            pin.title = myTitles[latLongCounter]
            latLongCounter += 1
        }
        let locationManager = CLLocationManager()
        locationManager.requestWhenInUseAuthorization()
        myMap.showsUserLocation = true
        myMap.delegate = self

        // Do any additional setup after loading the view.
    }
    
    //MARK: MKMapViewDelegate
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        // If annotation is not of type landmarkAnnotation (MKUserLocation types for instance), return nil
        if !(annotation is MKPointAnnotation){
            return nil
        }
        
        var annotationView = self.myMap.dequeueReusableAnnotationView(withIdentifier: "Pin")
        
        if annotationView == nil{
            annotationView = MKPinAnnotationView(annotation: annotation, reuseIdentifier: "Pin")
            annotationView?.canShowCallout = true
        }else{
            annotationView?.annotation = annotation
        }
        
        var landmarkAnnotation = annotation as! MKPointAnnotation
        
        // Right accessory view
        let button = UIButton(type: .infoLight)
        annotationView?.rightCalloutAccessoryView = button
        return annotationView
    }
    
    func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView, calloutAccessoryControlTapped control: UIControl) {
        let placemark = MKPlacemark(coordinate: view.annotation!.coordinate, addressDictionary: nil)
        // The map item is the restaurant location
        let mapItem = MKMapItem(placemark: placemark)
        
        let launchOptions = [MKLaunchOptionsDirectionsModeKey:MKLaunchOptionsDirectionsModeWalking]
        mapItem.openInMaps(launchOptions: launchOptions)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
