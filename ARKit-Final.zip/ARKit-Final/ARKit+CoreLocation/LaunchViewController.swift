//
//  LaunchViewController.swift
//  ARKit+CoreLocation
//
//  Created by Karolina Sabonaityte on 4/16/19.
//  Copyright © 2019 Project Dent. All rights reserved.
//

import UIKit

class LaunchViewController: UIViewController {

    @IBOutlet var watchTutorial: UIButton!
    @IBOutlet var exploreNow: UIButton!
    @IBAction func prepareForUnwind(segue: UIStoryboardSegue) {
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        watchTutorial.layer.shadowColor = UIColor.red.cgColor
        watchTutorial.layer.shadowOffset = CGSize(width: 5, height: 5)
        watchTutorial.layer.shadowRadius = 5
        watchTutorial.layer.shadowOpacity = 1.0
        watchTutorial.layer.cornerRadius = 5
        
        exploreNow.layer.shadowColor = UIColor.black.cgColor
        exploreNow.layer.shadowOffset = CGSize(width: 5, height: 5)
        exploreNow.layer.shadowRadius = 5
        exploreNow.layer.shadowOpacity = 1.0
        exploreNow.layer.cornerRadius = 5
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
