//
//  TableViewController.swift
//  Augmented UGA
//
//  Created by Karolina Sabonaityte on 2/24/19.
//  Copyright © 2019 Karolina Sabonaityte. All rights reserved.
//

import UIKit

@available(iOS 11.0, *)
class TableViewController: UITableViewController {
    
    @IBOutlet var navBar3: UINavigationBar!
    @IBOutlet var navTitle3: UINavigationItem!
    
    var myDataForTable = ["Herty Fountain","Sanford Stadium","Chapel Bell","The Arch"]
    var smallPixForTable = ["hertyFountain.jpg","sanfordStadium.jpg","chapelBell.jpg","theArch.jpg"]
    var index: Int!
    
    override func viewDidLoad() {
        let statusBar: UIView = UIApplication.shared.value(forKey: "statusBar") as! UIView
        if statusBar.responds(to: "setBackgroundColor:") {
            statusBar.backgroundColor = UIColor.red
        }
        let attributes = [NSAttributedString.Key.font: UIFont(name: "LeagueGothic-Regular", size: 35)!]
        navBar3.barTintColor = UIColor.red
        navBar3.titleTextAttributes = attributes
        navTitle3.title = "Augmented UGA"
        
        super.viewDidLoad()
        self.tableView.rowHeight = 110
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false
        
        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }
    
    // MARK: - Table view data source
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return myDataForTable.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Henry", for: indexPath)
        
        let myContent = myDataForTable[indexPath.row]
        let theImage = smallPixForTable[indexPath.row]
        // Configure the cell...
        cell.textLabel?.text = myContent
        cell.imageView?.image = UIImage(named: theImage)
        return cell
    }
    
    /*
     // Override to support conditional editing of the table view.
     override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
     // Return false if you do not want the specified item to be editable.
     return true
     }
     */
    
    /*
     // Override to support editing the table view.
     override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
     if editingStyle == .delete {
     // Delete the row from the data source
     tableView.deleteRows(at: [indexPath], with: .fade)
     } else if editingStyle == .insert {
     // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
     }
     }
     */
    
    /*
     // Override to support rearranging the table view.
     override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {
     
     }
     */
    
    /*
     // Override to support conditional rearranging of the table view.
     override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
     // Return false if you do not want the item to be re-orderable.
     return true
     }
     */
    
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
        let indexPath = tableView.indexPathForSelectedRow
        let index = indexPath?.row
        let receiverView = segue.destination as! ARCLViewController
        receiverView.passedInfo = index
     }
}
