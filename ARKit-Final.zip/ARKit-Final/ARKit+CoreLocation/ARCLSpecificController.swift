//
//  ARCLSpecificController.swift
//  ARKit+CoreLocation
//
//  Created by Andrew Hart on 02/07/2017.
//  Copyright © 2017 Project Dent. All rights reserved.
//

import UIKit
import SceneKit
import MapKit
import ARCL

@available(iOS 11.0, *)
class ARCLSpecificController: UIViewController {
    @IBOutlet var mapView: MKMapView!
    @IBOutlet var infoLabel: UILabel!
    @IBOutlet var contentView: UIView!
    @IBAction func backButton() {
        self.performSegue(withIdentifier: "unwindToViewController5", sender: self)
        
    }
    @IBOutlet var navItem: UINavigationItem!
    
    var titleText = String()
    
    var passedInfo: Int!
    let sceneLocationView = SceneLocationView()
    
    var userAnnotation: MKPointAnnotation?
    var locationEstimateAnnotation: MKPointAnnotation?
    
    var updateUserLocationTimer: Timer?
    var updateInfoLabelTimer: Timer?
    
    var centerMapOnUserLocation: Bool = true
    var routes: [MKRoute]?
    
    var showMap = true {
        didSet {
            guard let mapView = mapView else {
                return
            }
            mapView.isHidden = !showMap
        }
    }
    
    /// Whether to display some debugging data
    /// This currently displays the coordinate of the best location estimate
    /// The initial value is respected
    let displayDebugging = false
    
    let adjustNorthByTappingSidesOfScreen = false
    
    class func loadFromStoryboard() -> ARCLSpecificController {
        return UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ARCLSpecificController") as! ARCLSpecificController
        // swiftlint:disable:previous force_cast
    }
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        updateInfoLabelTimer = Timer.scheduledTimer(timeInterval: 0.1,
                                                    target: self,
                                                    selector: #selector(ARCLSpecificController.updateInfoLabel),
                                                    userInfo: nil,
                                                    repeats: true)
        
        // Set to true to display an arrow which points north.
        // Checkout the comments in the property description and on the readme on this.
        //        sceneLocationView.orientToTrueNorth = false
        //        sceneLocationView.locationEstimateMethod = .coreLocationDataOnly
        
        sceneLocationView.showAxesNode = true
        sceneLocationView.showFeaturePoints = displayDebugging
        
        // Now add the route or location annotations as appropriate
        addSceneModels()
        
        contentView.addSubview(sceneLocationView)
        sceneLocationView.frame = contentView.bounds
        
        mapView.isHidden = !showMap
        
        if showMap {
            updateUserLocationTimer = Timer.scheduledTimer(
                timeInterval: 0.5,
                target: self,
                selector: #selector(ARCLSpecificController.updateUserLocation),
                userInfo: nil,
                repeats: true)
            
            routes?.forEach { mapView.addOverlay($0.polyline) }
        }
        
        var myTitles = ["The Arch", "Chapel Bell", "Herty Fountain", "Miller Learning Center", "Tate Center", "Sanford Stadium"]
        var latLong = [[33.957547,-83.375286],[33.956620,-83.375395],[33.955703,-83.375511],[33.951700,-83.376100],[33.950500,-83.375000],[33.949800,-83.373366]]
        
        let howMany = latLong.count
        var latLongCounter = 0
        while (latLongCounter < howMany) {
            let pinLatitude = latLong[latLongCounter][0]
            let pinLongitude = latLong[latLongCounter][1]
            var pinCoordinates: CLLocationCoordinate2D = CLLocationCoordinate2D()
            pinCoordinates.latitude = CDouble(pinLatitude)
            pinCoordinates.longitude = CDouble(pinLongitude)
            let pin: MKPointAnnotation = MKPointAnnotation()
            pin.coordinate = pinCoordinates
            self.mapView.addAnnotation(pin)
            pin.title = myTitles[latLongCounter]
            latLongCounter += 1
        }
        
        let locationManager = CLLocationManager()
        locationManager.requestWhenInUseAuthorization()
        mapView.showsUserLocation = true
        mapView.delegate = self
        navigationItem.title = titleText
        
        let request = MKDirections.Request()
        request.source = MKMapItem.forCurrentLocation()
        if titleText == "The Arch" {
            request.destination = MKMapItem(placemark: MKPlacemark(coordinate: CLLocationCoordinate2D(latitude: latLong[0][0], longitude: latLong[0][1])))
        } else if titleText == "Chapel Bell" {
            request.destination = MKMapItem(placemark: MKPlacemark(coordinate: CLLocationCoordinate2D(latitude: latLong[1][0], longitude: latLong[1][1])))
        } else if titleText == "Herty Fountain" {
            request.destination = MKMapItem(placemark: MKPlacemark(coordinate: CLLocationCoordinate2D(latitude: latLong[2][0], longitude: latLong[2][1])))
        } else if titleText == "Miller Learning Center" {
            request.destination = MKMapItem(placemark: MKPlacemark(coordinate: CLLocationCoordinate2D(latitude: latLong[3][0], longitude: latLong[3][1])))
        } else if titleText == "Tate Center" {
            request.destination = MKMapItem(placemark: MKPlacemark(coordinate: CLLocationCoordinate2D(latitude: latLong[4][0], longitude: latLong[4][1])))
        } else if titleText == "Sanford Stadium" {
            request.destination = MKMapItem(placemark: MKPlacemark(coordinate: CLLocationCoordinate2D(latitude: latLong[5][0], longitude: latLong[5][1])))
        }
        request.requestsAlternateRoutes = true
        request.transportType = .walking
        let directions = MKDirections(request: request)
        directions.calculate { [unowned self] response, error in
            guard let unwrappedResponse = response else { return }
            
            for route in unwrappedResponse.routes {
                self.mapView.addOverlay(route.polyline)
                self.mapView.setVisibleMapRect(route.polyline.boundingMapRect, animated: true)
            }
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(false, animated: animated)
        sceneLocationView.run()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        // Pause the view's session
        sceneLocationView.pause()
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        sceneLocationView.frame = contentView.bounds
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesBegan(touches, with: event)
        guard let touch = touches.first,
            let view = touch.view else { return }
        
        if mapView == view || mapView.recursiveSubviews().contains(view) {
            centerMapOnUserLocation = false
        } else {
            let location = touch.location(in: self.view)
            
            if location.x <= 40 && adjustNorthByTappingSidesOfScreen {
                print("left side of the screen")
                sceneLocationView.moveSceneHeadingAntiClockwise()
            } else if location.x >= view.frame.size.width - 40 && adjustNorthByTappingSidesOfScreen {
                print("right side of the screen")
                sceneLocationView.moveSceneHeadingClockwise()
            } else {
                let image = UIImage(named: "pin")!
                let annotationNode = LocationAnnotationNode(location: nil, image: image)
                annotationNode.scaleRelativeToDistance = true
                sceneLocationView.addLocationNodeForCurrentPosition(locationNode: annotationNode)
            }
        }
    }
}

// MARK: - MKMapViewDelegate

@available(iOS 11.0, *)
extension ARCLSpecificController: MKMapViewDelegate {
    
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        let renderer = MKPolylineRenderer(overlay: overlay)
        renderer.lineWidth = 3
        renderer.strokeColor = UIColor.blue.withAlphaComponent(0.5)
        
        return renderer
    }
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        guard !(annotation is MKUserLocation),
            let pointAnnotation = annotation as? MKPointAnnotation else { return nil }
        
        let marker = MKMarkerAnnotationView(annotation: annotation, reuseIdentifier: nil)
        
        if pointAnnotation == self.userAnnotation {
            marker.displayPriority = .required
            marker.glyphImage = UIImage(named: "user")
        } else {
            marker.displayPriority = .required
            marker.markerTintColor = UIColor(hue: 0.267, saturation: 0.67, brightness: 0.77, alpha: 1.0)
            marker.glyphImage = UIImage(named: "compass")
        }
        
        return marker
    }
}

// MARK: - Implementation

@available(iOS 11.0, *)
extension ARCLSpecificController {
    
    /// Adds the appropriate ARKit models to the scene.  Note: that this won't
    /// do anything until the scene has a `currentLocation`.  It "polls" on that
    /// and when a location is finally discovered, the models are added.
    func addSceneModels() {
        // 1. Don't try to add the models to the scene until we have a current location
        guard sceneLocationView.sceneLocationManager.currentLocation != nil else {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) { [weak self] in
                self?.addSceneModels()
            }
            return
        }
        
        // 2. If there is a route, show that
        if let routes = routes {
            sceneLocationView.addRoutes(routes: routes)
        } else {
            // 3. If not, then show the
            buildDemoData().forEach {
                sceneLocationView.addLocationNodeWithConfirmedLocation(locationNode: $0)
            }
        }
    }
    
    /// Builds the location annotations for a few random objects, scattered across the country
    ///
    /// - Returns: an array of annotation nodes.
    func buildDemoData() -> [LocationAnnotationNode] {
        var nodes: [LocationAnnotationNode] = []
        
        if titleText == "The Arch" {
            let theArch = buildViewNode(latitude: 33.957547, longitude: -83.375286, altitude: 200, text: "The Arch")
            nodes.append(theArch)
        } else if titleText == "Chapel Bell" {
            let chapelBell = buildViewNode(latitude: 33.956620, longitude: -83.375395, altitude: 200, text: "Chapel Bell")
            nodes.append(chapelBell)
        } else if titleText == "Herty Fountain" {
            let hertyFountain = buildViewNode(latitude: 33.955703, longitude: -83.375511, altitude: 200, text: "Herty Fountain")
            nodes.append(hertyFountain)
        } else if titleText == "Miller Learning Center" {
            let millerCenter = buildViewNode(latitude: 33.951700, longitude: -83.376100, altitude: 200, text: "Miller Learning Center")
            nodes.append(millerCenter)
        } else if titleText == "Tate Center" {
            let tateCenter = buildViewNode(latitude: 33.950500, longitude: -83.375000, altitude: 200, text: "Tate Center")
            nodes.append(tateCenter)
        } else if titleText == "Sanford Stadium" {
            let sanfordStadium = buildViewNode(latitude: 33.949800, longitude: -83.373366, altitude: 200, text: "Sanford Stadium")
            nodes.append(sanfordStadium)
        }
        
        return nodes
    }
    
    @objc
    func updateUserLocation() {
        guard let currentLocation = sceneLocationView.sceneLocationManager.currentLocation else {
            return
        }
        
        DispatchQueue.main.async { [weak self ] in
            guard let self = self else {
                return
            }
            
            if self.userAnnotation == nil {
                self.userAnnotation = MKPointAnnotation()
                self.mapView.addAnnotation(self.userAnnotation!)
            }
            
            UIView.animate(withDuration: 0.5, delay: 0, options: .allowUserInteraction, animations: {
                self.userAnnotation?.coordinate = currentLocation.coordinate
            }, completion: nil)
            
            if self.centerMapOnUserLocation {
                UIView.animate(withDuration: 0.45,
                               delay: 0,
                               options: .allowUserInteraction,
                               animations: {
                                self.mapView.setCenter(self.userAnnotation!.coordinate, animated: false)
                }, completion: { _ in
                    self.mapView.region.span = MKCoordinateSpan(latitudeDelta: 0.0005, longitudeDelta: 0.0005)
                })
            }
            
            if self.displayDebugging {
                if let bestLocationEstimate = self.sceneLocationView.sceneLocationManager.bestLocationEstimate {
                    if self.locationEstimateAnnotation == nil {
                        self.locationEstimateAnnotation = MKPointAnnotation()
                        self.mapView.addAnnotation(self.locationEstimateAnnotation!)
                    }
                    self.locationEstimateAnnotation?.coordinate = bestLocationEstimate.location.coordinate
                } else if self.locationEstimateAnnotation != nil {
                    self.mapView.removeAnnotation(self.locationEstimateAnnotation!)
                    self.locationEstimateAnnotation = nil
                }
            }
        }
    }
    
    @objc
    func updateInfoLabel() {
        if let position = sceneLocationView.currentScenePosition {
            infoLabel.text = "x: \(position.x.short), y: \(position.y.short), z: \(position.z.short)\n"
        }
        
        if let eulerAngles = sceneLocationView.currentEulerAngles {
            infoLabel.text!.append("Euler x: \(eulerAngles.x.short), y: \(eulerAngles.y.short), z: \(eulerAngles.z.short)\n")
        }
        
        let comp = Calendar.current.dateComponents([.hour, .minute, .second, .nanosecond], from: Date())
        if let hour = comp.hour, let minute = comp.minute, let second = comp.second, let nanosecond = comp.nanosecond {
            infoLabel.text!.append("\(hour.short):\(minute.short):\(second.short):\(nanosecond.short3)")
        }
    }
    
    func buildNode(latitude: CLLocationDegrees, longitude: CLLocationDegrees,
                   altitude: CLLocationDistance, imageName: String) -> LocationAnnotationNode {
        let coordinate = CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
        let location = CLLocation(coordinate: coordinate, altitude: altitude)
        let image = UIImage(named: imageName)!
        return LocationAnnotationNode(location: location, image: image)
    }
    
    func buildViewNode(latitude: CLLocationDegrees, longitude: CLLocationDegrees,
                       altitude: CLLocationDistance, text: String) -> LocationAnnotationNode {
        let coordinate = CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
        let location = CLLocation(coordinate: coordinate, altitude: altitude)
        let label = UILabel(frame: CGRect(x: 0, y: 0, width: 200, height: 50))
        label.layer.masksToBounds = true
        label.layer.cornerRadius = 8
        label.font = UIFont(name: "Montserrat-Light.otf", size: 22)
        label.text = text
        label.backgroundColor = .white
        label.textAlignment = .center
        return LocationAnnotationNode(location: location, view: label)
    }
}
