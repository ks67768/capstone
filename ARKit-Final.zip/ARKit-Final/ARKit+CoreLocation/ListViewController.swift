//
//  ListViewController.swift
//  ARKit+CoreLocation
//
//  Created by Karolina Sabonaityte on 4/11/19.
//  Copyright © 2019 Project Dent. All rights reserved.
//

import UIKit

class Cell: UITableViewCell {
    @IBOutlet var image3: UIImageView!
    @IBOutlet var title3: UILabel!
}

@available(iOS 11.0, *)
class ListViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet var tableView: UITableView!
    @IBOutlet var navItem: UINavigationItem!
    @IBAction func homeButton() {
        self.performSegue(withIdentifier: "unwindToViewController3", sender: self)
    }
    @IBAction func prepareForUnwind2(segue: UIStoryboardSegue) {
        
    }
    
    var myTitles = ["The Arch", "Chapel Bell", "Herty Fountain", "Miller Learning Center", "Tate Center", "Sanford Stadium"]
    var myPix = [UIImage(named: "theArch.jpg"),UIImage(named: "chapelBell.jpg"),UIImage(named: "hertyFountain.jpg"),UIImage(named: "millerCenter.jpg"),UIImage(named: "tateCenter.jpg"),UIImage(named: "sanfordStadium.jpg")]
    var infoText = [("At nearly 160 years old, the cast iron Arch bordering downtown Athens marks the entrance to campus and is the most iconic symbol of the university. Each of the three pillars of the Arch stand for wisdom, justice, and moderation, which is the state motto for Georgia."),("The iconic Chapel Bell was originally built in 1832 in a cupola cup atop the Chapel. In 1913, the bell started to fall through its sills and was moved to a trestle constructed behind the Chapel. Today, the former church now hosts lectures, events, weddings and remains home to the Chapel Bell, a university landmark."),("Herty Field was UGA’s first athletic field and was originally used for both UGA football and baseball games. This was the site of our first intercollegiate football game where UGA defeated Mercer in January of 1892 with a score of 50-0. Herty Field and the Fountain are an iconic site on campus, known particularly for its North Campus beauty."),("The Miller Learning Center, opened in 2003, houses classrooms and library space in the heart of campus. The MLC acts as the ultimate study spot for UGA students. Inside, it is compiled of 96 study rooms, 374 computer workstations, 26 classrooms, a digital media lab, and a silent library."),("Named for the late William Tate, the center contains a food court, a 500-seat movie theater, dance studios, the university’s student-run radio station, and much more. Tate Center is a LEED building meaning, Leadership in Energy and Environmental Design."),("Sanford Stadium, home to the University of Georgia Bulldogs football team, was originally constructed in 1929. The first game to take place “in between the hedges” was Georgia v. Yale. Located in the heart of campus, Sanford Stadium is one of the largest college football stadiums in the country with a capacity of 92,746.")]
    var extraText = [("FUN FACT! “The Arch” was actually called “The Gate” until the early 20th century."),("FUN FACT! The tradition of ringing the bell for Bulldawg victories is still used today, in addition to numerous other special events people celebrate while on campus! Can you say GOOOO DAWGS!"),("FUN FACT! Herty Field is now used for a numerous different recreational activities by Greek Life, School clubs, and much more!"),("FUN FACT! This central campus hub just celebrated 16 years of service to UGA’s students!"),("FUN FACT! The first construction of the Tate Center took 23 years of planning and phase 2, which was completed in 2009, double the original structure in size."),("FUN FACT! Sanford Stadium played host to the 1996 Olympic Games for the medal round of the finals in soccer which was watched by over three billion people worldwide.")]
    var index: Int!
    
    override func viewDidLoad() {
        navigationItem.title = "All Locations"
        super.viewDidLoad()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "sendDataSegue" {
            let backItem = UIBarButtonItem()
            backItem.title = "Back"
            navigationItem.backBarButtonItem = backItem
            
            let indexPaths = self.tableView!.indexPathsForSelectedRows!
            let indexPath = indexPaths[0] as NSIndexPath
            let vc = segue.destination as! InfoViewController
            vc.image = self.myPix[indexPath.row]!
            vc.textt = self.infoText[indexPath.row]
            vc.text2 = self.extraText[indexPath.row]
            vc.titleText = self.myTitles[indexPath.row]
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! Cell
        cell.title3.text = myTitles[indexPath.row]
        cell.image3.image = myPix[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return myTitles.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        /*self.performSegue(withIdentifier: "sendDataSegue", sender: self)*/
    }
}
