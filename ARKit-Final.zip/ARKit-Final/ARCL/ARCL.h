//
//  ARCL.h
//  ARCL
//
//  Created by Aaron Brethorst on 5/29/18.
//  Copyright © 2018 Project Dent. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ARCL.
FOUNDATION_EXPORT double ARCLVersionNumber;

//! Project version string for ARCL.
FOUNDATION_EXPORT const unsigned char ARCLVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ARCL/PublicHeader.h>


